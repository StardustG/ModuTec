package com.mycompany.modutech.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
   public static Connection getConexao(){
       try{ 
           Connection connection = DriverManager.getConnection( "jdbc:mysql://localhost:3306/modutec");
           System.out.println("Conectado com sucesso!");
           return connection;
       }catch(SQLException e){
           System.out.println("Erro de conecção com o banco de dados, se o problema persistir entre em contato com a Stardust Soft.");
       }
       return null;
   } 
    public static void main(String[] args) {
        Conexao.getConexao();
        
    }

    public static Connection getConnection(String jdbcmysqllocalhost3306modutec) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}
