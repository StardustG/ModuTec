package dao;

import com.mycompany.modutech.Utils.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Agenda;

public class AgendaDao {

    public static void SaveOrUpdate(Agenda agenda) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Connection connection = Conexao.getConnection( "jdbc:mysql://localhost:3306/modutec");
    private Object level;
    public void save (Agenda agenda) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("INSERT INTO clientes (compromisso, descricao, observacoes, dataAtual, dataFinal) VALUES (?,?,?,?,?)");      
        ps.setString(1, "compromisso");
        ps.setString(2, "descricao");
        ps.setString(3, "observacoes");
        ps.setString(4, "dataAtual");
        ps.setString(5, "dataFinal");
        JOptionPane.showMessageDialog(null, "Compromisso cadastrado com sucesso!");
        }catch(SQLException ex){
             Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);     
        }
}
    public void update (Agenda agenda) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("UPDATE clientes SET (compromisso =?, descricao =?, observacoes =?, dataAtual =?, dataFinal =? WHERE codigoCL=?)");
        ps.setString(1, agenda.getCompromisso());
        ps.setString(2, agenda.getDescrição());
        ps.setString(3, agenda.getObservações());
        ps.setString(4, agenda.getDataAtual());
        ps.setString(5, agenda.getDataFinal());
        JOptionPane.showMessageDialog(null, "Agenda atualizada com sucesso!");
        }catch(SQLException ex){
               Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void saveOrUpdate(Agenda agenda) throws SQLException{
    if(agenda.getCodigo() == 0){
        save(agenda);
    }else{
        update(agenda);
    }
    }
}