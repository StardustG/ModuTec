package dao;

import com.mycompany.modutech.Utils.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Clientes;

public class ClientesDao {

    public static void SaveOrUpdate(Clientes cliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Connection connection = Conexao.getConnection( "jdbc:mysql://localhost:3306/modutec");
    private Object level;
    public void save (Clientes cliente) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("INSERT INTO clientes (nome,endereco, cidade, cep, tel, bairro, email, cpf_cnpj, rg, obsGeraisCL) VALUES (?,?,?,?,?,?,?,?,?,?)");      
        ps.setString(1, "nome");
        ps.setString(2, "endereco");
        ps.setString(3, "cidade");
        ps.setString(4, "cep");
        ps.setString(5, "tel");
        ps.setString(6, "bairro");
        ps.setString(7, "email");
        ps.setString(8, "cpf_cnpj");
        ps.setString(9, "rg");
        ps.setString(10, "obsGeraisC");
        JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");
        }catch(SQLException ex){
             Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);     
        }
}
    public void update (Clientes cliente) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("UPDATE clientes SET (nome=? ,endereco=?, cidade=?, cep=?, tel=?, bairro=?, email=?, cpf_cnpj=?, rg=?, obsGeraisCL=? WHERE codigoCL=?)");
        ps.setString(1, cliente.getNomeClientes());
        ps.setString(2, cliente.getEnderecoClientes());
        ps.setString(3, cliente.getCidadeClientes());
        ps.setString(4, cliente.getCEPClientes());
        ps.setString(5, cliente.getTelClientes());
        ps.setString(6, cliente.getBairroClientes());
        ps.setString(7, cliente.getEmailClientes());
        ps.setString(8, cliente.getRgCliente());
        ps.setString(9, cliente.getCPFCNPJ());
        ps.setString(10, cliente.getRgCliente());
        ps.setString(10, cliente.getObservacoesGeraisClientes());
        JOptionPane.showMessageDialog(null, "Cliente atualizado com sucesso!");
        }catch(SQLException ex){
               Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void saveOrUpdate(Clientes cliente) throws SQLException{
    if(cliente.getCodigo() == 0){
        save(cliente);
    }else{
        update(cliente);
    }
    }
}