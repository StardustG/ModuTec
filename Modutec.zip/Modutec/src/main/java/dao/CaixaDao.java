package dao;

import com.mycompany.modutech.Utils.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Caixa;

public class CaixaDao {

    public static void SaveOrUpdate(Caixa caixa) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Connection connection = Conexao.getConnection( "jdbc:mysql://localhost:3306/modutec");
    private Object level;
    public void save (Caixa caixa) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("INSERT INTO clientes (valor, descricao, observacoes, data) VALUES (?,?,?,?)");      
        ps.setString(1, "data");
        ps.setString(2, "descricao");
        ps.setString(3, "observacoes");
        ps.setString(4, "valor");

        JOptionPane.showMessageDialog(null, "Operação cadastrada com sucesso!");
        }catch(SQLException ex){
             Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);     
        }
}
    public void update (Caixa caixa) throws SQLException{
        try{
        PreparedStatement ps = connection.prepareStatement("UPDATE caixa SET valor = ? , descricao = ? , observacoes = ? , data = ? WHERE codigoCL=?)");
        ps.setString(1, caixa.getData());
        ps.setString(2, caixa.getDescrição());
        ps.setString(3, caixa.getObservações());
        ps.setString(4, caixa.getValor());
        JOptionPane.showMessageDialog(null, "Caixa atualizado com sucesso!");
        }catch(SQLException ex){
               Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
}
    public void saveOrUpdate(Caixa caixa) throws SQLException{
    if(caixa.getCodigo() == 0){
        save(caixa);
    }else{
        update(caixa);
    }
    }
}