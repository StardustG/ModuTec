/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javax.swing.JTextField;

/**
 *
 * @author pinhe
 */
public class Agenda {
  private int codigo;
  private String Descrição;
  private String Compromisso;
  private String Observações;
  private String DataAtual;
  private String DataFinal;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescrição() {
        return Descrição;
    }

    public void setDescrição(String Descrição) {
        this.Descrição = Descrição;
    }

    public String getCompromisso() {
        return Compromisso;
    }

    public void setCompromisso(String Compromisso) {
        this.Compromisso = Compromisso;
    }

    public String getObservações() {
        return Observações;
    }

    public void setObservações(String Observações) {
        this.Observações = Observações;
    }

    public String getDataAtual() {
        return DataAtual;
    }

    public void setDataAtual(String DataAtual) {
        this.DataAtual = DataAtual;
    }

    public String getDataFinal() {
        return DataFinal;
    }

    public void setDataFinal(String DataFinal) {
        this.DataFinal = DataFinal;
    }

    public void setcompromisso(JTextField Compromisso) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setobservacoes(JTextField Descrição) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setdataAtual(JTextField DataAtual) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setdataFinal(JTextField DataFinal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setdescricao(JTextField Descrição) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
