/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javax.swing.JTextField;

/**
 *
 * @author pinhe
 */
public class Funcionarios {
  private int codigo;
  private String NomeFuncionarios;
  private String EnderecoFuncionarios;
  private String CidadeFuncionarios;
  private String CEPFuncionarios;
  private String BairroFuncionarios;
  private String TelFuncionarios;
  private String rgFuncionarios;
  private String EmailFuncionarios;
  private String CPF;
  private String ObservacoesGeraisFuncionarios;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomeFuncionarios() {
        return NomeFuncionarios;
    }

    public void setNomeFuncionarios(String NomeFuncionarios) {
        this.NomeFuncionarios = NomeFuncionarios;
    }

    public String getEnderecoFuncionarios() {
        return EnderecoFuncionarios;
    }

    public void setEnderecoFuncionarios(String EnderecoFuncionarios) {
        this.EnderecoFuncionarios = EnderecoFuncionarios;
    }

    public String getCidadeFuncionarios() {
        return CidadeFuncionarios;
    }

    public void setCidadeFuncionarios(String CidadeFuncionarios) {
        this.CidadeFuncionarios = CidadeFuncionarios;
    }

    public String getCEPFuncionarios() {
        return CEPFuncionarios;
    }

    public void setCEPFuncionarios(String CEPFuncionarios) {
        this.CEPFuncionarios = CEPFuncionarios;
    }

    public String getBairroFuncionarios() {
        return BairroFuncionarios;
    }

    public void setBairroFuncionarios(String BairroFuncionarios) {
        this.BairroFuncionarios = BairroFuncionarios;
    }

    public String getTelFuncionarios() {
        return TelFuncionarios;
    }

    public void setTelFuncionarios(String TelFuncionarios) {
        this.TelFuncionarios = TelFuncionarios;
    }

    public String getRgFuncionarios() {
        return rgFuncionarios;
    }

    public void setRgCliente(String rgFuncionarios) {
        this.rgFuncionarios = rgFuncionarios;
    }

    public String getEmailFuncionarios() {
        return EmailFuncionarios;
    }

    public void setEmailFuncionarios(String EmailFuncionarios) {
        this.EmailFuncionarios = EmailFuncionarios;
    }

    public String getCPFCNPJ() {
        return CPF;
    }

    public void setCPFCNPJ(String CPF) {
        this.CPF = CPF;
    }

    public String getObservacoesGeraisClientes() {
        return ObservacoesGeraisFuncionarios;
    }

    public void setObservacoesGeraisFuncionarios(String ObservacoesGeraisFuncionarios) {
        this.ObservacoesGeraisFuncionarios= ObservacoesGeraisFuncionarios;
    }

    public int getCodigoFn() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getNome() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getEndereco() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getCidade() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getCep() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getTel() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getEmail() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getBairro() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getCpf() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getRg() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getObsGeraisFn() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setnome(JTextField Nome) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setendereco(JTextField Endereço) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcidade(JTextField Cidade) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcep(JTextField CEP) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void settel(JTextField Tel) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setrg(JTextField RG) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setbairro(JTextField Bairro) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcpf_cnpj(JTextField CPF) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setobsGeraisFn(JTextField ObsGerais) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setemail(JTextField Email) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
