package dao;

import com.mycompany.modutech.Utils.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Fornecedores;

public class FornecedoresDao {
    private Connection connection = Conexao.getConnection("jdbc:mysql://localhost:3306/modutec");
    private Object level;

    public void save(Fornecedores fornecedor) throws SQLException {
        try {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO fornecedores (nome, endereco, cidade, cep, tel, bairro, email, cnpj, rg, obsGeraisFr) VALUES (?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, fornecedor.getNome());
            ps.setString(2, fornecedor.getEndereco());
            ps.setString(3, fornecedor.getCidade());
            ps.setString(4, fornecedor.getCep());
            ps.setString(5, fornecedor.getTel());
            ps.setString(6, fornecedor.getBairro());
            ps.setString(7, fornecedor.getEmail());
            ps.setString(8, fornecedor.getCnpj());
            ps.setString(9, fornecedor.getRg());
            ps.setString(10, fornecedor.getObsGeraisFr());
            JOptionPane.showMessageDialog(null, "Fornecedor cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(FornecedoresDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(Fornecedores fornecedor) throws SQLException {
        try {
            PreparedStatement ps = connection.prepareStatement("UPDATE fornecedores SET nome=?, endereco=?, cidade=?, cep=?, tel=?, bairro=?, email=?, cnpj=?, rg=?, obsGeraisFr=? WHERE codigoFr=?");
            ps.setString(1, fornecedor.getNome());
            ps.setString(2, fornecedor.getEndereco());
            ps.setString(3, fornecedor.getCidade());
            ps.setString(4, fornecedor.getCep());
            ps.setString(5, fornecedor.getTel());
            ps.setString(6, fornecedor.getBairro());
            ps.setString(7, fornecedor.getEmail());
            ps.setString(8, fornecedor.getCnpj());
            ps.setString(9, fornecedor.getRg());
            ps.setString(10, fornecedor.getObsGeraisFr());
            JOptionPane.showMessageDialog(null, "Fornecedor atualizado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(FornecedoresDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void saveOrUpdate(Fornecedores fornecedor) throws SQLException {
        if (fornecedor.getCodigoFr() == 0) {
            save(fornecedor);
        } else {
            update(fornecedor);
        }
    }
}