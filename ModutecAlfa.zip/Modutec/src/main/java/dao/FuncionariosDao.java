package dao;

import com.mycompany.modutech.Utils.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Funcionarios;

public class FuncionariosDao {
    private Connection connection = Conexao.getConnection("jdbc:mysql://localhost:3306/modutec");
    private Object level;

    public void save(Funcionarios funcionario) throws SQLException {
        try {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO funcionarios (nome, endereco, cidade, cep, tel, bairro, email, cpf, rg, obsGeraisFn) VALUES (?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, funcionario.getNome());
            ps.setString(2, funcionario.getEndereco());
            ps.setString(3, funcionario.getCidade());
            ps.setString(4, funcionario.getCep());
            ps.setString(5, funcionario.getTel());
            ps.setString(6, funcionario.getBairro());
            ps.setString(7, funcionario.getEmail());
            ps.setString(8, funcionario.getCpf());
            ps.setString(9, funcionario.getRg());
            ps.setString(10, funcionario.getObsGeraisFn());
            JOptionPane.showMessageDialog(null, "Funcionario cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(FuncionariosDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(Funcionarios funcionario) throws SQLException {
        try {
            PreparedStatement ps = connection.prepareStatement("UPDATE funcionarios SET nome=?, endereco=?, cidade=?, cep=?, tel=?, bairro=?, email=?, cpf=?, rg=?, obsGeraisFn=? WHERE codigoFn=?");
            ps.setString(1, funcionario.getNome());
            ps.setString(2, funcionario.getEndereco());
            ps.setString(3, funcionario.getCidade());
            ps.setString(4, funcionario.getCep());
            ps.setString(5, funcionario.getTel());
            ps.setString(6, funcionario.getBairro());
            ps.setString(7, funcionario.getEmail());
            ps.setString(8, funcionario.getCpf());
            ps.setString(9, funcionario.getRg());
            ps.setString(10, funcionario.getObsGeraisFn());
            JOptionPane.showMessageDialog(null, "Funcionario atualizado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(FuncionariosDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void saveOrUpdate(Funcionarios funcionario) throws SQLException {
        if (funcionario.getCodigoFn() == 0) {
            save(funcionario);
        } else {
            update(funcionario);
        }
    }
}