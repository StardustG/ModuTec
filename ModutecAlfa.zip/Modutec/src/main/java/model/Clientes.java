package model;
public class Clientes {
  private int codigo;
  private String NomeClientes;
  private String EnderecoClientes;
  private String CidadeClientes;
  private String CEPClientes;
  private String BairroClientes;
  private String TelClientes;
  private String rgCliente;
  private String EmailClientes;
  private String CPFCNPJ;
  private String ObservacoesGeraisClientes;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomeClientes() {
        return NomeClientes;
    }

    public void setNomeClientes(String NomeClientes) {
        this.NomeClientes = NomeClientes;
    }

    public String getEnderecoClientes() {
        return EnderecoClientes;
    }

    public void setEnderecoClientes(String EnderecoClientes) {
        this.EnderecoClientes = EnderecoClientes;
    }

    public String getCidadeClientes() {
        return CidadeClientes;
    }

    public void setCidadeClientes(String CidadeClientes) {
        this.CidadeClientes = CidadeClientes;
    }

    public String getCEPClientes() {
        return CEPClientes;
    }

    public void setCEPClientes(String CEPClientes) {
        this.CEPClientes = CEPClientes;
    }

    public String getBairroClientes() {
        return BairroClientes;
    }

    public void setBairroClientes(String BairroClientes) {
        this.BairroClientes = BairroClientes;
    }

    public String getTelClientes() {
        return TelClientes;
    }

    public void setTelClientes(String TelClientes) {
        this.TelClientes = TelClientes;
    }

    public String getRgCliente() {
        return rgCliente;
    }

    public void setRgCliente(String rgCliente) {
        this.rgCliente = rgCliente;
    }

    public String getEmailClientes() {
        return EmailClientes;
    }

    public void setEmailClientes(String EmailClientes) {
        this.EmailClientes = EmailClientes;
    }

    public String getCPFCNPJ() {
        return CPFCNPJ;
    }

    public void setCPFCNPJ(String CPFCNPJ) {
        this.CPFCNPJ = CPFCNPJ;
    }

    public String getObservacoesGeraisClientes() {
        return ObservacoesGeraisClientes;
    }

    public void setObservacoesGeraisClientes(String ObservacoesGeraisClientes) {
        this.ObservacoesGeraisClientes = ObservacoesGeraisClientes;
    }
}
