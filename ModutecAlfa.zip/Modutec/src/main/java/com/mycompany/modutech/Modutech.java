/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.modutech;

/**
 *
 * @author pinhe
 */
public class Modutech {

    public static void main(String[] args) {
        ModutecInicial Inicio = new  ModutecInicial();
        Inicio.setVisible(true);
    }
}
